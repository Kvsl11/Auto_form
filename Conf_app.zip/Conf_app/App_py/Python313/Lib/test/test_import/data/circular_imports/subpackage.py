"""Circular import involving a sub-package."""
from .subpkg import subpackage2
