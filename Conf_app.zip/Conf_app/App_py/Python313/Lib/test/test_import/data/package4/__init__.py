"""Binding the package attribute without importing the module."""
class submodule:
    attr = 'origin'
    class B:
        attr = 'origin'
